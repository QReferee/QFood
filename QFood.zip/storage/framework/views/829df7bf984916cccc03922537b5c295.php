<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title
            inertia><?php echo e(config('app.name', 'QFood.Site - Создаем професcиональные сайты для ресторанов, кафе и доставок еды')); ?></title>

        <link rel="icon" href="https://qfood.site/img/logo.webp" type="image/x-icon">
        <!-- Scripts -->
        <?php echo app('Tighten\Ziggy\BladeRouteGenerator')->generate(); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js', "resources/js/Pages/{$page['component']}.vue"]); ?>
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>

        <?php $url = explode('/', $page['component']) ?>

        <?php if(count($url) > 0): ?>
            <?php if($url[0] == 'Admin'): ?>
                <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.css" rel="stylesheet"/>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.js"></script>
            <?php endif; ?>
        <?php endif; ?>
    </head>
    <body>

    <?php if(count($url) > 0): ?>
        <?php if($url[0] != 'Admin'): ?>
            <script>
                window.replainSettings = {id: '69a92d71-5e1a-4fd2-a697-50da9e813eee'};
                (function (u) {
                    var s = document.createElement('script');
                    s.async = true;
                    s.src = u;
                    var x = document.getElementsByTagName('script')[0];
                    x.parentNode.insertBefore(s, x);
                })('https://widget.replain.cc/dist/client.js');
            </script>
        <?php endif; ?>
    <?php endif; ?>
    <div class="follow-cursor"></div>
    <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
    </body>
</html>
<?php /**PATH C:\Projects\Website\QFood\resources\views/app.blade.php ENDPATH**/ ?>