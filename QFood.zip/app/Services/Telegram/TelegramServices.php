<?php

namespace App\Services\Telegram;

class TelegramServices
{
    public string $token = '7094459101:AAEp-acIkDdT1xDiKbQH2IIE5e5-2EMGV5s';
    public string $token2 = '6767833513:AAG0lSwJWwMWF1Ty3GRB9FETSuaTqNEbd2A';
    public int $chatID = 911281987;
    public int $chatID2 = 891954506;
}
