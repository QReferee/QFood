<?php

namespace App\Services\Upload;

use Illuminate\Support\Facades\Storage;

class UploadServices
{
    protected $data;

    public function __construct($data)
    {
        $this->data = $data;
    }

    public function upload()
    {
        $fileName = time() . '.' . $this->data['file']->extension();
        $this->data['file']->storeAs('public/images', $fileName);

        return response()->json([
            'file' => '/storage/images/' . $fileName
        ]);
    }
}
